package edu.upenn.cis.cis455.m1.interfaces;

import edu.upenn.cis.cis455.SparkController;
import edu.upenn.cis.cis455.m1.server.HttpListener;
import edu.upenn.cis.cis455.m1.server.HttpWorker;
import edu.upenn.cis.cis455.m1.server.WebService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class RequestHandler {
    final static Logger logger = LogManager.getLogger(RequestHandler.class);
    private HttpRequest request;
    private Response response;
    static String control = "<!DOCTYPE html>\n" +
            "<html lang=\"en\">\n" +
            "<head>\n" +
            "    <meta charset=\"UTF-8\">\n" +
            "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n" +
            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
            "    <title>Lol</title>\n" +
            "</head>\n" +
            "<body>\n" +
            "    <h1>Control Panel</h1>\n" +
            "    \n" +
            "</body>\n" +
            "</html>";

    public RequestHandler(HttpRequest request, Response response) {
        this.request = request;
        this.response = response;
    }

    public String WorkerList() {
        StringBuilder tmp = new StringBuilder("<ul>");
        List<HttpWorker> workers = SparkController.getInstance().getPool().getWorkers();
        for (HttpWorker w : workers) {
            tmp.append("<li>");
            tmp.append(w.getId()).append(" ").append(w.getStatus()).append(workers.size());
            logger.info(w.getId() + w.getStatus());
            tmp.append("<li>");
        }
        tmp.append("</ul>");
        return tmp.toString();
    }


    public void handle() {
        String uri = request.uri;
        String protocol= request.protocol();
        String method = request.requestMethod();
        String host = request.host();
        logger.info("protoco: "+ protocol);
        logger.info("method: " + method);
        logger.info("host: " + host);
        if(method.equals("GET")){
            if (uri.equals("/control")) {
                response.status(200);
                StringBuilder tmp = new StringBuilder();
                tmp.append(protocol).append(" ");
                tmp.append("200 OK\r\n");
                tmp.append("Content-Type: text/html\r\n");

                String list = WorkerList();
                String button = "\n" +
                        "<button onclick=\"location.href='/shutdown'\" type=\"button\">\n" +
                        "         shutdown</button>";
                String body = control + list + button;

                byte[] content = body.getBytes(StandardCharsets.UTF_8);
                int len = content.length;

                tmp.append("Content-Length: ").append(len).append("\r\n");
                tmp.append("\r\n");
                tmp.append(body);
//            tmp.append("what the hell");
                tmp.append("\r\n");
                response.body(tmp.toString());
            } else if (uri.equals("/shutdown")) {
                logger.info("-----------------shutdown handler");
                response.status(500);
                StringBuilder tmp = new StringBuilder();
                tmp.append(protocol).append(" ");
                tmp.append("200 OK\r\n");
                tmp.append("Content-Type: text/html\r\n");
                String body = "Shutdown";
                String list = WorkerList();
                body = body + list;
                byte[] content = body.getBytes(StandardCharsets.UTF_8);
                int len = content.length;
                tmp.append("Content-Length: ").append(len).append("\r\n");
                tmp.append("\r\n");
                tmp.append(body);
                response.body(tmp.toString());
                SparkController.getInstance().stop();
            } else {
                logger.info("get uri.html");
                Path path = Paths.get(WebService.staticFileLocation + "/"+uri);
                logger.info(path);
                logger.info(path.toString());
                logger.info(path.toAbsolutePath());
                String type ="text/html";
                try {
                    type = Files.probeContentType(path);
                    logger.info("type changed");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                logger.info(type);
                if (!Files.exists(path)) {
                    String st = "<h1> 404 Not Found</h1>";
                    int len = st.getBytes(StandardCharsets.UTF_8).length;
                    logger.info("No such file");
                    response.status(404);
                    StringBuilder tmp = new StringBuilder();
                    tmp.append(protocol).append(" ");
                    tmp.append("404 NOT FOUND");
                    tmp.append("Content-Type: ");
                    tmp.append(type);
                    tmp.append("Content-Length: ").append(len).append("\r\n");
                    tmp.append("\r\n");
                    tmp.append(st);
                    response.body(tmp.toString());
                } else {
                    logger.info("file found, read the file");
                    StringBuilder tmp = new StringBuilder();
                    byte[] body = null;
                    try {
                        body = Files.readAllBytes(path);
                    } catch (IOException e) {
                        logger.debug("THE FILE IS NOT FOUND");
                    }
                    tmp.append(protocol).append(" ");
                    tmp.append("200 OK\r\n");
                    tmp.append("Content-Type: ");
                    tmp.append(type).append("\r\n");
                    tmp.append("Content-Length: ").append(body.length).append("\r\n");
                    tmp.append("\r\n");
                    byte[] header = tmp.toString().getBytes(StandardCharsets.UTF_8);
                    body = addByteArray(header, body);
                    response.bodyRaw(body);
                }
            }
        }else{
            response.status(505);
            StringBuilder tmp = new StringBuilder();
            tmp.append(protocol).append(" ");
            tmp.append("505 HTTP Version Not Supported");
            tmp.append("Content-Type: ");
            tmp.append("test/html");
            tmp.append("Content-Length: 0").append("\r\n");
            tmp.append("\r\n");
            response.body(tmp.toString());
        }

    }

    public static byte[] addByteArray(byte[] a, byte[] b){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
        try {
            outputStream.write(a);
            outputStream.write( b );
        } catch (IOException e) {
            logger.warn("append byte array fail");
        }
        byte c[] = outputStream.toByteArray( );
        return c;
    }
}
