package edu.upenn.cis.cis455.m1.interfaces;

import edu.upenn.cis.cis455.m1.server.HttpTask;
import edu.upenn.cis.cis455.m1.server.HttpWorker;

import java.util.Map;
import java.util.Set;

public class HttpRequest extends Request{

    private Map<String,String> headers;
    private HttpTask task;

    public HttpRequest(HttpTask task, Map<String, String> headers, String uri){
        super();
        this.task = task;
        this.port = task.getSocket().getPort();
        this.ip = task.getSocket().getInetAddress().toString();
        this.uri = uri;
        this.headers = headers;
        for(Map.Entry<String,String> entry : headers.entrySet()){
            String key = entry.getKey();
            String val = entry.getValue();
            switch (key){
                case "host":
                    this.host = val;
                    break;
                case "Method":
                    this.requestMethod = val;
                    break;
                case "user-agent":
                    this.userAgent = val;
                    break;
                case "protocolVersion":
                    this.protocal = val;
                    break;
            }
        }

    }


    @Override
    public String requestMethod() {
        return requestMethod;
    }

    @Override
    public String host() {
        return host;
    }

    @Override
    public String userAgent() {
        return null;
    }

    @Override
    public int port() {
        return 0;
    }

    @Override
    public String pathInfo() {
        return null;
    }

    @Override
    public String url() {
        return host + uri;
    }

    @Override
    public String uri() {return uri;
    }

    @Override
    public String protocol() {
        return protocal;
    }

    @Override
    public String contentType() {
        return null;
    }

    @Override
    public String ip() {
        return null;
    }

    @Override
    public String body() {
        return null;
    }

    @Override
    public int contentLength() {
        return 0;
    }

    @Override
    public String headers(String name) {
        return null;
    }

    @Override
    public Set<String> headers() {
        return null;
    }
}
