package edu.upenn.cis.cis455.m2.impl;

public class SessionImpl {
}
