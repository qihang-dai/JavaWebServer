package edu.upenn.cis.cis455.m2.impl;

import edu.upenn.cis.cis455.m2.interfaces.Request;
import edu.upenn.cis.cis455.m2.interfaces.Response;
import edu.upenn.cis.cis455.m2.interfaces.Route;

public class RouteImpl implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        return null;
    }
}
